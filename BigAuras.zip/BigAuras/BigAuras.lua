hooksecurefunc("TargetFrame_UpdateAuraPositions", function(
		self, auraName, numAuras, numOppositeAuras, largeAuraList, updateFunc, maxRowWidth, offsetX
	)
	local AURA_OFFSET_Y = 3
	local size
	local offsetY = AURA_OFFSET_Y
	local rowWidth = 0
	local firstBuffOnRow = 1

	if maxRowWidth ~= 80 then
		maxRowWidth = 126
	end
	
	for i = 1, numAuras do
		if largeAuraList[i] then
			size = 27
			offsetY = AURA_OFFSET_Y + AURA_OFFSET_Y
		else
			size = 22
		end

		if i == 1 then
			rowWidth = size
		else
			rowWidth = rowWidth + size + offsetX
		end
		
		if rowWidth > maxRowWidth then
			updateFunc(self, auraName, i, numOppositeAuras, firstBuffOnRow, size, offsetX, offsetY)

			rowWidth = size
			firstBuffOnRow = i
			offsetY = AURA_OFFSET_Y
		else
			updateFunc(self, auraName, i, numOppositeAuras, i - 1, size, offsetX, offsetY)
		end
	end
end)

for _, f in ipairs({TargetFrameToT, FocusFrameToT}) do
	f:ClearAllPoints()
	f:SetPoint("BOTTOMRIGHT", -5, -15)
end